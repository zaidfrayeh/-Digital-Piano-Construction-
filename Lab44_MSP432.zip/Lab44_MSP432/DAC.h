/*
 * DAC.h
 *
 *  Created on: Mar 7, 2023
 *      Author: djfrayeh
 */

#ifndef DAC_H_
#define DAC_H_


void DAC_INIT(void);
void DAC_OUT(uint32_t data);


#endif /* DAC_H_ */
