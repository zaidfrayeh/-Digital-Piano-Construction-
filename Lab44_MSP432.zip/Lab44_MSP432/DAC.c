#include <stdint.h>
#include "SOUND.h"
#include "msp432p401r.h"
#include "DAC.h"
#define DAC_out (*((volatile uint8_t *)0x40004C23))


void DAC_INIT(void)
{
            //output pins for dac port 4 pins 0-3
            P4SEL0 &= ~0x0F;
            P4SEL1 &= ~0x0F;
            P4DIR  |= 0x0F;

}
void DAC_OUT( uint32_t data )
{

    DAC_out=data;
}
