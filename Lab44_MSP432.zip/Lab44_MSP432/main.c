#include <stdint.h>
#include "msp432p401r.h"
#include "SOUND.h"
#include "PIANO.h"
#include "SysTickInts.h"



void main(void){

     uint8_t PIANO = 0;


      PIANO_INIT();
      Sound_Init();


      EnableInterrupts();
      WaitForInterrupt();


      while(1) {
       PIANO = PIANO_IN();

                                   if(PIANO == 0x00)
                                   {
                                       SysTick->LOAD=0;

                                   }
                                   else if(PIANO == 0x01)
                                   {
                                       SysTick->LOAD=269;

                                   }

                                   else if(PIANO == 0x02)
                                   {
                                       SysTick->LOAD = 190;

                                   }

                                   else if(PIANO == 0x04)
                                   {
                                       SysTick->LOAD = 213;

                                   }

      }
};

