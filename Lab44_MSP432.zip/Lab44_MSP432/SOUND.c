#include <stdint.h>
#include "msp432p401r.h"
#include "SOUND.h"
#include "DAC.h"
#include "SysTickInts.h"


    int sound = 0;
    int indx = 0;

const uint8_t wave[32]= {
   8,9,11,12,13,14,14,15,15,15,14,
   14,13,12,11,9,8,7,5,4,3,2,
   2,1,1,1,2,2,3,4,5,7};

void Sound_Init(void){

    DAC_INIT();
    SysTick_Init(0);
}


void Sound_play(uint8_t note){


    if(note == 1)      {

            indx = (indx + 1) &0x1f ;
            DAC_OUT(wave[indx]);
                       }

    else if(note == 2) {

            indx = (indx + 1) &0x1f ;
            DAC_OUT(wave[indx]);

                        }

    else if (note == 4) {

           indx = (indx + 1) &0x1f ;
            DAC_OUT(wave[indx]);

                        }

    else if(note == 0)  {
            DAC_OUT(0);

                        }

}


