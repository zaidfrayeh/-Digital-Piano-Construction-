// SysTickInts.c
// Runs on MSP432
// Use the SysTick timer to request interrupts at a particular period.
// Daniel Valvano, Jonathan Valvano
// June 1, 2015

/* This example accompanies the books
   "Embedded Systems: Introduction to MSP432 Microcontrollers",
   ISBN: 978-1469998749, Jonathan Valvano, copyright (c) 2015
   Volume 1 Program 9.7

 Copyright 2015 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */

#include <stdint.h>
#include "SOUND.h"
#include "PIANO.h"
#include "DAC.h"
#include "msp432p401r.h"
//int sound = 0;
//int indx = 0;

void DisableInterrupts(void); // Disable interrupts
void EnableInterrupts(void);  // Enable interrupts
long StartCritical (void);    // previous I bit, disable interrupts
void EndCritical(long sr);    // restore I bit to previous value
void WaitForInterrupt(void);  // low power mode
volatile uint32_t Counts;
volatile uint32_t note;

void SysTick_Init(uint32_t period) {
	long sr = StartCritical();

	Counts = 0;

	SysTick->CTRL = 0;                   // disable SysTick during setup
	SysTick->LOAD = period - 1;          // maximum reload value
	SysTick->VAL = 0;                    // any write to current clears it
	SCB->SHP[3] = (SCB->SHP[3]&0x00FFFFFF)|0x40000000;	// priority 2
	SysTick->CTRL = 0x00000007;          // enable SysTick with no interrupts

	EndCritical(sr);
}

void SysTick_Handler(void){
                                   if(SysTick->LOAD == 213)
                                       {
                                           Sound_play(4);
                                       }
                                       else if(SysTick->LOAD == 190)
                                       {
                                            Sound_play(2);
                                       }

                                       else if(SysTick->LOAD == 269)
                                       {
                                           Sound_play(1);
                                       }

                                       else if(SysTick->LOAD == 0)
                                       {
                                           Sound_play(0);
                                       }
}


