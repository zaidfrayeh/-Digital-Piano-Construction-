/*
 * PIANO.h
 *
 *  Created on: Mar 8, 2023
 *      Author: djfrayeh
 */

#ifndef PIANO_H_
#define PIANO_H_

void PIANO_INIT(void);

int PIANO_IN( void);


#endif /* PIANO_H_ */
