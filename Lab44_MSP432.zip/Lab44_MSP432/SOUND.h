/*
 * SOUND.h
 *
 *  Created on: Mar 8, 2023
 *      Author: djfrayeh
 */

#ifndef SOUND_H_
#define SOUND_H_
void Sound_Init(void);
void Sound_play(uint8_t note);


#endif /* SOUND_H_ */
