/*
 * PIANO.c
 *
 *  Created on: Mar 8, 2023
 *      Author: djfrayeh
 */
#include <stdint.h>
#include "msp432p401r.h"
#include "piano.h"
#define piano_Input (*((volatile uint8_t *)0x40004C40))

//input port 5 pins 5.4 5.5 5.6 because other pins are giving wrong values
void PIANO_INIT(void){
            P5SEL0 &= ~0x70;
            P5SEL1 &= ~0x70;
            P5DIR  &= ~0x70;
}
int PIANO_IN(void){
        uint32_t input;
        input = (piano_Input&0x70);
        input= input/16;
        return input;

}

